SHIVERBUG STUDIOS - PRESS KIT
=============================

Shiverbug Studios Ltd
North East England, United Kingdom
Registered in England and Wales, company no. 16485763

Press contact : contact@shiverbugstudios.com
Web           : https://olivernealdev.github.io/ShiverbugStudiosWebsite/
Press kit     : https://olivernealdev.github.io/ShiverbugStudiosWebsite/press.html
Socials       : https://linktr.ee/shiverbugstudios


WHAT'S IN HERE
--------------

logos-and-brand/
  logo-svg-rgb/    Primary lockup as vector, for screen. Use these by default.
  logo-svg-cmyk/   The same lockups with CMYK colour values, for print.
  logo-png/        Raster fallbacks at 1711px, plus the icon and wordmark on
                   their own.

  Naming: "-white" and "-black" are the transparent lockups, named for the
  colour of the artwork. Use -white on dark backgrounds, -black on light ones.
  "on-black", "on-white" and "on-blue" have the background baked in.

  Brand colours and typefaces, and the rules for using the logo, are set out on
  the press kit page linked above.

screenshots/       Out of Water, full resolution.
studio/            Team photography.
video/             Out of Water trailer (from the ProtoPlay build; a new one is
                   in production).


PERMISSIONS
-----------

You have permission to use anything in this kit in articles, videos, streams
and other coverage of Shiverbug Studios and our games, including monetised
coverage, without asking us first and without paying us anything.

Please don't stretch, rotate, recolour, outline or add effects to the logo, and
please don't use it in a way that implies we endorse or are involved in a
product we aren't.

Screenshots are from a build in development and do not represent the finished
game.

Need something that isn't here - a specific shot, an interview, an asset at a
particular size? Email contact@shiverbugstudios.com and we'll sort it.
