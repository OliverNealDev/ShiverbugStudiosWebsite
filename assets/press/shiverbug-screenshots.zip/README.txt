SHIVERBUG STUDIOS - PRESS KIT
=============================

Shiverbug Studios Ltd
North East England, United Kingdom
Registered in England and Wales, company no. 16485763

Press contact : contact@shiverbugstudios.com
Web           : https://shiverbugstudios.com/
Press kit     : https://shiverbugstudios.com/press.html
Socials       : https://linktr.ee/shiverbugstudios

WHAT'S IN HERE
--------------

screenshots/        Out of Water, full resolution. From a build in development.
studio/             Team photography: Develop:Brighton 2026, and Tranzfuser
                    2025 at ProtoPlay, where Out of Water won the public vote.

Logos and the brand pack are a separate download, on the press kit page linked
above. The trailer is there too.

PERMISSIONS
-----------

You have permission to use anything in this kit in articles, videos, streams
and other coverage of Shiverbug Studios and our games, including monetised
coverage, without asking us first and without paying us anything.

Please don't stretch, rotate, recolour, outline or add effects to the logo, and
please don't use it in a way that implies we endorse or are involved in a
product we aren't.

Screenshots are from a build in development and do not represent the finished
game.

Need something that isn't here - a specific shot, an interview, an asset at a
particular size? Email contact@shiverbugstudios.com and we'll sort it.